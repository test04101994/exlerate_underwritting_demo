"""Test connectivity to Okta OAuth2 token endpoint and the dragon-policy API.

Configuration is read from config.ini. All output goes through the logging module.
"""

import sys
import json
import socket
import logging
import argparse
import configparser
from datetime import datetime
from pathlib import Path
from urllib.parse import urlparse

import requests
from openpyxl import Workbook, load_workbook
from tqdm import tqdm
from tqdm.contrib.logging import logging_redirect_tqdm


log = logging.getLogger("connectivity")

TRACE_COLUMNS = ["request_policy", "request_dol", "captured_at"]


def configure_logging(level: str, log_file: str) -> None:
    fmt = "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
    formatter = logging.Formatter(fmt)

    root = logging.getLogger()
    root.setLevel(getattr(logging, level.upper(), logging.INFO))
    root.handlers.clear()

    stream = logging.StreamHandler(sys.stdout)
    stream.setFormatter(formatter)
    root.addHandler(stream)

    if log_file:
        file_handler = logging.FileHandler(log_file)
        file_handler.setFormatter(formatter)
        root.addHandler(file_handler)


def load_config(path: Path) -> configparser.ConfigParser:
    if not path.exists():
        raise FileNotFoundError(f"Config file not found: {path}")
    cfg = configparser.ConfigParser()
    cfg.read(path)
    return cfg


def check_dns(url: str) -> None:
    host = urlparse(url).hostname
    log.info("Resolving DNS for %s", host)
    try:
        ip = socket.gethostbyname(host)
        log.info("DNS resolved %s -> %s", host, ip)
    except socket.gaierror as e:
        log.error("DNS lookup failed for %s: %s", host, e)
        raise


def get_token(cfg: configparser.ConfigParser, verify_tls: bool, timeout: int) -> str:
    token_url = cfg["okta"]["token_url"]
    client_id = cfg["okta"]["client_id"]
    client_secret = cfg["okta"]["client_secret"]
    scope = cfg["okta"]["scope"]

    if not client_secret:
        raise ValueError("okta.client_secret is empty in config.ini")

    log.info("Step 1: requesting OAuth2 access token")
    log.info("token_url=%s client_id=%s scope=%s", token_url, client_id, scope)
    check_dns(token_url)

    resp = requests.post(
        token_url,
        data={"grant_type": "client_credentials", "scope": scope},
        auth=(client_id, client_secret),
        headers={"Accept": "application/json"},
        timeout=timeout,
        verify=verify_tls,
    )
    log.info("token endpoint responded HTTP %s %s", resp.status_code, resp.reason)

    if not resp.ok:
        log.error("token request failed body=%s", resp.text)
        resp.raise_for_status()

    body = resp.json()
    token = body.get("access_token")
    if not token:
        raise RuntimeError(f"No access_token in response: {body}")

    log.info(
        "token acquired token_type=%s expires_in=%s len=%d",
        body.get("token_type"),
        body.get("expires_in"),
        len(token),
    )
    log.debug("access_token prefix: %s...", token[:20])
    return token


def call_dragon_policy(
    url: str,
    token: str,
    payload: dict,
    verify_tls: bool,
    timeout: int,
) -> dict:
    log.info("calling dragon-policy payload=%s", json.dumps(payload))

    resp = requests.post(
        url,
        json=payload,
        headers={
            "Authorization": f"Bearer {token}",
            "Accept": "application/json",
            "Content-Type": "application/json",
        },
        timeout=timeout,
        verify=verify_tls,
    )
    log.info("dragon-policy responded HTTP %s %s", resp.status_code, resp.reason)
    log.debug("response headers: %s", dict(resp.headers))

    resp.raise_for_status()

    try:
        body = resp.json()
    except ValueError:
        log.error("response body was not JSON: %s", resp.text)
        raise

    log.debug("response body: %s", json.dumps(body, default=str))
    return body


_DOL_PARSE_FORMATS = (
    "%Y-%m-%d %H:%M:%S",
    "%Y-%m-%d",
    "%m/%d/%Y",
    "%m/%d/%Y %H:%M:%S",
    "%d-%b-%y",
    "%d-%b-%Y",
)


def format_dol(value, output_format: str) -> str:
    """Convert an Excel cell value (datetime or string) into the dol string the API expects."""
    if value is None:
        raise ValueError("dol value is None")
    if isinstance(value, datetime):
        return value.strftime(output_format).upper()
    text = str(value).strip()
    for fmt in _DOL_PARSE_FORMATS:
        try:
            return datetime.strptime(text, fmt).strftime(output_format).upper()
        except ValueError:
            continue
    log.warning("could not parse dol %r — passing through unchanged", text)
    return text


def read_input_rows(
    excel_path: Path,
    sheet_name: str,
    policy_column: str,
    dol_column: str,
) -> list[dict]:
    if not excel_path.exists():
        raise FileNotFoundError(f"Input Excel not found: {excel_path}")
    log.info("reading input %s sheet=%s", excel_path, sheet_name)
    wb = load_workbook(excel_path, read_only=True, data_only=True)
    if sheet_name not in wb.sheetnames:
        raise ValueError(
            f"Sheet '{sheet_name}' not found in {excel_path}. Available sheets: {wb.sheetnames}"
        )
    ws = wb[sheet_name]
    rows_iter = ws.iter_rows(values_only=True)
    try:
        header = list(next(rows_iter))
    except StopIteration:
        raise ValueError(f"Sheet '{sheet_name}' is empty")

    if policy_column not in header:
        raise ValueError(f"policy_column '{policy_column}' not in header. Got: {header}")
    if dol_column not in header:
        raise ValueError(f"dol_column '{dol_column}' not in header. Got: {header}")

    p_idx = header.index(policy_column)
    d_idx = header.index(dol_column)

    rows = []
    for r_idx, row in enumerate(rows_iter, start=2):
        if not row or all(c is None for c in row):
            continue
        policy = row[p_idx]
        dol = row[d_idx]
        if policy is None or str(policy).strip() == "":
            log.warning("row %d: missing %s, skipping", r_idx, policy_column)
            continue
        if dol is None:
            log.warning("row %d: missing %s for policy=%s, skipping", r_idx, dol_column, policy)
            continue
        rows.append({"row_number": r_idx, "policy": str(policy).strip(), "dol_raw": dol})

    log.info("loaded %d input row(s) from %s", len(rows), excel_path)
    return rows


def run_batch(
    cfg: configparser.ConfigParser,
    token: str,
    verify_tls: bool,
    timeout: int,
    limit: int | None,
) -> tuple[int, int, int]:
    """Returns (rows_processed, rows_failed, records_written)."""
    api_url = cfg["api"]["url"]
    input_path = Path(cfg["input"]["excel_file"])
    rows = read_input_rows(
        excel_path=input_path,
        sheet_name=cfg["input"]["sheet_name"],
        policy_column=cfg["input"]["policy_column"],
        dol_column=cfg["input"]["dol_column"],
    )
    dol_format = cfg.get("input", "dol_format", fallback="%d-%b-%y")
    if limit is not None:
        rows = rows[:limit]
        log.info("limit=%d applied; processing first %d row(s)", limit, len(rows))

    output_path = Path(cfg.get("output", "excel_file", fallback="policy_results.xlsx"))
    sheet_name = cfg.get("output", "sheet_name", fallback="PolicySearch")
    append = cfg.getboolean("output", "append", fallback=True)

    check_dns(api_url)

    def write_placeholder(payload: dict) -> None:
        try:
            write_to_excel(
                body={},
                request_payload=payload,
                excel_path=output_path,
                sheet_name=sheet_name,
                append=append,
            )
        except Exception as e:
            log.error("could not write placeholder row for policy=%s: %s", payload.get("policy"), e)

    processed = 0
    failed = 0
    total_written = 0
    with logging_redirect_tqdm():
        progress = tqdm(rows, desc="policies", unit="row")
        for i, row in enumerate(progress, start=1):
            progress.set_postfix_str(f"policy={row['policy']}")
            try:
                dol = format_dol(row["dol_raw"], dol_format)
            except Exception as e:
                log.error("row %d (policy=%s): cannot format dol %r — %s",
                          row["row_number"], row["policy"], row["dol_raw"], e)
                write_placeholder({"policy": row["policy"], "dol": str(row["dol_raw"]) if row["dol_raw"] is not None else ""})
                failed += 1
                continue

            payload = {"policy": row["policy"], "dol": dol}
            log.info("[%d/%d] row=%d policy=%s dol=%s", i, len(rows), row["row_number"], payload["policy"], payload["dol"])
            try:
                body = call_dragon_policy(api_url, token, payload, verify_tls=verify_tls, timeout=timeout)
            except Exception as e:
                log.error("row %d (policy=%s, dol=%s) API call failed: %s",
                          row["row_number"], payload["policy"], payload["dol"], e)
                write_placeholder(payload)
                failed += 1
                continue

            try:
                written = write_to_excel(
                    body=body,
                    request_payload=payload,
                    excel_path=output_path,
                    sheet_name=sheet_name,
                    append=append,
                )
                total_written += written
            except Exception as e:
                log.error("row %d (policy=%s) write failed: %s",
                          row["row_number"], payload["policy"], e)
                failed += 1
                continue

            processed += 1

    log.info("batch complete: processed=%d failed=%d records_written=%d",
             processed, failed, total_written)
    return processed, failed, total_written


def _flatten_value(value):
    """Excel cells can't hold dicts/lists — JSON-encode them."""
    if isinstance(value, (dict, list)):
        return json.dumps(value, ensure_ascii=False)
    return value


def _discover_keys(records: list[dict]) -> list[str]:
    """Union of keys across records, preserving first-seen order."""
    seen: dict[str, None] = {}
    for rec in records:
        for k in rec.keys():
            if k not in seen:
                seen[k] = None
    return list(seen.keys())


def write_to_excel(
    body: dict,
    request_payload: dict,
    excel_path: Path,
    sheet_name: str,
    append: bool,
) -> int:
    """Write PolicySearch records to Excel.

    If the response has no usable records, writes a single placeholder row
    (data columns blank, trace columns populated) so input/output rows align.
    """
    records_raw = body.get("PolicySearch") if isinstance(body, dict) else None
    if records_raw is not None and not isinstance(records_raw, list):
        log.warning("PolicySearch is not a list (got %s)", type(records_raw).__name__)
        records_raw = None
    records = [r for r in (records_raw or []) if isinstance(r, dict)]
    is_placeholder = not records
    if is_placeholder:
        log.warning(
            "no PolicySearch records for policy=%s dol=%s — writing placeholder row",
            request_payload.get("policy"), request_payload.get("dol"),
        )

    new_data_keys = _discover_keys(records)
    use_existing = excel_path.exists() and append

    if use_existing:
        wb = load_workbook(excel_path)
        if sheet_name in wb.sheetnames:
            ws = wb[sheet_name]
        else:
            ws = wb.create_sheet(sheet_name)
        log.info("Appending to existing workbook %s sheet=%s", excel_path, sheet_name)

        existing_header = [c.value for c in ws[1]] if ws.max_row >= 1 else []
        existing_header = [h for h in existing_header if h is not None]

        if not existing_header:
            header = new_data_keys + TRACE_COLUMNS
            ws.append(header)
        else:
            existing_data = [h for h in existing_header if h not in TRACE_COLUMNS]
            added = [k for k in new_data_keys if k not in existing_data]
            if added:
                log.info("response contains %d new field(s) not in existing sheet: %s", len(added), added)
            header = existing_data + added + TRACE_COLUMNS
            if header != existing_header:
                for col_idx, name in enumerate(header, start=1):
                    ws.cell(row=1, column=col_idx, value=name)
    else:
        wb = Workbook()
        ws = wb.active
        ws.title = sheet_name
        header = new_data_keys + TRACE_COLUMNS
        ws.append(header)
        log.info("Creating new workbook %s sheet=%s with %d columns", excel_path, sheet_name, len(header))

    captured_at = datetime.utcnow().isoformat(timespec="seconds") + "Z"

    def make_row(rec: dict | None) -> list:
        row = []
        for col in header:
            if col == "request_policy":
                row.append(request_payload.get("policy"))
            elif col == "request_dol":
                row.append(request_payload.get("dol"))
            elif col == "captured_at":
                row.append(captured_at)
            else:
                row.append(_flatten_value(rec.get(col)) if rec else None)
        return row

    if is_placeholder:
        ws.append(make_row(None))
        wb.save(excel_path)
        log.info("saved 1 placeholder row to %s", excel_path)
        return 1

    written = 0
    for rec in records:
        ws.append(make_row(rec))
        written += 1
        log.info(
            "wrote row policyid=%s policy=%s insured=%s",
            rec.get("policyid"),
            rec.get("policy"),
            rec.get("insuredname"),
        )

    wb.save(excel_path)
    log.info("saved %d row(s) to %s (%d columns)", written, excel_path, len(header))
    return written


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--config",
        default="config.ini",
        help="Path to config file (default: config.ini)",
    )
    parser.add_argument(
        "--token-only",
        action="store_true",
        help="Only test token acquisition; skip the API call",
    )
    parser.add_argument(
        "--limit",
        type=int,
        default=None,
        help="In batch mode, process at most N input rows (useful for dry-runs)",
    )
    args = parser.parse_args()

    try:
        cfg = load_config(Path(args.config))
    except FileNotFoundError as e:
        logging.basicConfig(level=logging.ERROR)
        logging.error(str(e))
        return 2

    configure_logging(
        cfg.get("logging", "level", fallback="INFO"),
        cfg.get("logging", "file", fallback=""),
    )

    timeout = cfg.getint("http", "timeout", fallback=30)
    verify_tls = cfg.getboolean("http", "verify_tls", fallback=True)
    if not verify_tls:
        import urllib3
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        log.warning("TLS verification disabled via config")

    try:
        token = get_token(cfg, verify_tls=verify_tls, timeout=timeout)
        if args.token_only:
            log.info("token-only mode; skipping API call")
        else:
            input_file = cfg.get("input", "excel_file", fallback="").strip()
            output_file = cfg.get("output", "excel_file", fallback="").strip()

            if input_file:
                run_batch(cfg, token, verify_tls=verify_tls, timeout=timeout, limit=args.limit)
            else:
                payload = {"policy": cfg["api"]["policy"], "dol": cfg["api"]["dol"]}
                check_dns(cfg["api"]["url"])
                body = call_dragon_policy(
                    cfg["api"]["url"], token, payload,
                    verify_tls=verify_tls, timeout=timeout,
                )
                if output_file:
                    write_to_excel(
                        body=body,
                        request_payload=payload,
                        excel_path=Path(output_file),
                        sheet_name=cfg.get("output", "sheet_name", fallback="PolicySearch"),
                        append=cfg.getboolean("output", "append", fallback=True),
                    )
                else:
                    log.info("output.excel_file not set; skipping Excel write")
    except requests.exceptions.SSLError as e:
        log.exception("TLS error: %s", e)
        return 1
    except requests.exceptions.ConnectionError as e:
        log.exception("Connection error: %s", e)
        return 1
    except requests.exceptions.HTTPError as e:
        log.exception("HTTP error: %s", e)
        return 1
    except Exception as e:
        log.exception("Unexpected error: %s", e)
        return 1

    log.info("All checks passed")
    return 0


if __name__ == "__main__":
    sys.exit(main())
