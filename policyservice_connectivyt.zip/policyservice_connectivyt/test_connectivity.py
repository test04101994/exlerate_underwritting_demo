"""Test connectivity to Okta OAuth2 token endpoint and the dragon-policy API.

Configuration is read from config.ini. All output goes through the logging module.
"""

import sys
import json
import socket
import logging
import argparse
import configparser
from pathlib import Path
from urllib.parse import urlparse

import requests


log = logging.getLogger("connectivity")


def configure_logging(level: str, log_file: str) -> None:
    fmt = "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
    formatter = logging.Formatter(fmt)

    root = logging.getLogger()
    root.setLevel(getattr(logging, level.upper(), logging.INFO))
    root.handlers.clear()

    stream = logging.StreamHandler(sys.stdout)
    stream.setFormatter(formatter)
    root.addHandler(stream)

    if log_file:
        file_handler = logging.FileHandler(log_file)
        file_handler.setFormatter(formatter)
        root.addHandler(file_handler)


def load_config(path: Path) -> configparser.ConfigParser:
    if not path.exists():
        raise FileNotFoundError(f"Config file not found: {path}")
    cfg = configparser.ConfigParser()
    cfg.read(path)
    return cfg


def check_dns(url: str) -> None:
    host = urlparse(url).hostname
    log.info("Resolving DNS for %s", host)
    try:
        ip = socket.gethostbyname(host)
        log.info("DNS resolved %s -> %s", host, ip)
    except socket.gaierror as e:
        log.error("DNS lookup failed for %s: %s", host, e)
        raise


def get_token(cfg: configparser.ConfigParser, verify_tls: bool, timeout: int) -> str:
    token_url = cfg["okta"]["token_url"]
    client_id = cfg["okta"]["client_id"]
    client_secret = cfg["okta"]["client_secret"]
    scope = cfg["okta"]["scope"]

    if not client_secret:
        raise ValueError("okta.client_secret is empty in config.ini")

    log.info("Step 1: requesting OAuth2 access token")
    log.info("token_url=%s client_id=%s scope=%s", token_url, client_id, scope)
    check_dns(token_url)

    resp = requests.post(
        token_url,
        data={"grant_type": "client_credentials", "scope": scope},
        auth=(client_id, client_secret),
        headers={"Accept": "application/json"},
        timeout=timeout,
        verify=verify_tls,
    )
    log.info("token endpoint responded HTTP %s %s", resp.status_code, resp.reason)

    if not resp.ok:
        log.error("token request failed body=%s", resp.text)
        resp.raise_for_status()

    body = resp.json()
    token = body.get("access_token")
    if not token:
        raise RuntimeError(f"No access_token in response: {body}")

    log.info(
        "token acquired token_type=%s expires_in=%s len=%d",
        body.get("token_type"),
        body.get("expires_in"),
        len(token),
    )
    log.debug("access_token prefix: %s...", token[:20])
    return token


def call_dragon_policy(
    cfg: configparser.ConfigParser,
    token: str,
    verify_tls: bool,
    timeout: int,
) -> None:
    url = cfg["api"]["url"]
    payload = {"policy": cfg["api"]["policy"], "dol": cfg["api"]["dol"]}

    log.info("Step 2: calling dragon-policy API")
    log.info("url=%s payload=%s", url, json.dumps(payload))
    check_dns(url)

    resp = requests.post(
        url,
        json=payload,
        headers={
            "Authorization": f"Bearer {token}",
            "Accept": "application/json",
            "Content-Type": "application/json",
        },
        timeout=timeout,
        verify=verify_tls,
    )
    log.info("dragon-policy responded HTTP %s %s", resp.status_code, resp.reason)
    log.debug("response headers: %s", dict(resp.headers))

    try:
        log.info("response body: %s", json.dumps(resp.json()))
    except ValueError:
        log.info("response body (non-JSON): %s", resp.text)

    resp.raise_for_status()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--config",
        default="config.ini",
        help="Path to config file (default: config.ini)",
    )
    parser.add_argument(
        "--token-only",
        action="store_true",
        help="Only test token acquisition; skip the API call",
    )
    args = parser.parse_args()

    try:
        cfg = load_config(Path(args.config))
    except FileNotFoundError as e:
        logging.basicConfig(level=logging.ERROR)
        logging.error(str(e))
        return 2

    configure_logging(
        cfg.get("logging", "level", fallback="INFO"),
        cfg.get("logging", "file", fallback=""),
    )

    timeout = cfg.getint("http", "timeout", fallback=30)
    verify_tls = cfg.getboolean("http", "verify_tls", fallback=True)
    if not verify_tls:
        import urllib3
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        log.warning("TLS verification disabled via config")

    try:
        token = get_token(cfg, verify_tls=verify_tls, timeout=timeout)
        if not args.token_only:
            call_dragon_policy(cfg, token, verify_tls=verify_tls, timeout=timeout)
    except requests.exceptions.SSLError as e:
        log.exception("TLS error: %s", e)
        return 1
    except requests.exceptions.ConnectionError as e:
        log.exception("Connection error: %s", e)
        return 1
    except requests.exceptions.HTTPError as e:
        log.exception("HTTP error: %s", e)
        return 1
    except Exception as e:
        log.exception("Unexpected error: %s", e)
        return 1

    log.info("All checks passed")
    return 0


if __name__ == "__main__":
    sys.exit(main())
